﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace QLDongHo.Models
{
    public class Cart
    {
        private List<CartItem> _items;

        //phương thức khởi tạo giỏ hàng
        public Cart()
        {
            _items = new List<CartItem>();
        }
        //phương thức trả về danh sách các sản phẩm trong giỏ
        public List<CartItem> Items { get { return _items; } }
        //phương thức thêm sản phẩm vào giỏ
        public void Add(int masp)
        {
            //truy xuất CSDL để lấy thông tin về sản phẩm cần thêm vào giỏ hàng
            SqlConnection conn = new
            SqlConnection(ConfigurationManager.ConnectionStrings["DoAnDongHoConnectionString"].ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from DongHo where MaDH=@madh", conn);
            cmd.Parameters.AddWithValue("@madh", masp);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                //tạo đối tượng CartItem
                CartItem sp = new CartItem
                {
                    MaSP = masp,

                    TenSP = dr["TenDH"].ToString(),
                    Hinh = dr["HinhAnh"].ToString(),
                    DonGia = int.Parse(dr["DonGia"].ToString()),
                    SoLuong = 1
                };
                //thêm vào giỏ (đề nghị sinh viên tự lập trình
                // cho trường hợp sản phẩm đã có trong giỏ)
                _items.Add(sp);
            }
        }
        //Phương thức cập nhật số lượng,
        public void Update(int masp, int soluong)
        {
            int index = findId(masp);
            if (index != -1) //tìm thấy
            {
                if (soluong > 0)
                    _items[index].SoLuong = soluong;
                else
                    _items.RemoveAt(index);
            }
        }
        //phương thức xoá sản phẩm khỏi giỏ,
        public void Delete(int masp)
        {
            int index = findId(masp);
            if (index != -1) //tìm thấy
                _items.RemoveAt(index); //xoá khỏi giỏ hàng
        }
        private int findId(int masp)
        {
            for (int i = 0; i < _items.Count; i++)
            {
                if (_items[i].MaSP == masp)
                {
                    return i; //tìm thấy
                }
            }
            return -1;//không thấy
        }
        //tính tổng thành tiền
        public int Total
        {
            get
            {
                int tong = 0;
                foreach (CartItem item in _items)
                {
                    tong += item.ThanhTien;
                }
                return tong;
            }
        }
    }
}